package com.natamus.fullbrightnesstoggle.util;

public class Reference {
	public static final String MOD_ID = "fullbrightnesstoggle";
	public static final String NAME = "Full Brightness Toggle";
	public static final String VERSION = "4.5";
	public static final String ACCEPTED_VERSIONS = "[1.21.10]";
}
